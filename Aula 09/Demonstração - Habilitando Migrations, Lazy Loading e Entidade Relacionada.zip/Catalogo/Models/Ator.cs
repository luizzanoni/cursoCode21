﻿using Catalogo.MeuNamespace;

namespace Catalogo.Models
{
    public class Ator
    {
        public virtual int Id { get; set; }

        public virtual string Nome { get; set; }

        public virtual Filme Filme { get; set; }
    }
}
