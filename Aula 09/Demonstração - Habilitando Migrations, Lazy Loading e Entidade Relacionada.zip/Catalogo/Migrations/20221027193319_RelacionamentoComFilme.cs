﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Catalogo.Migrations
{
    public partial class RelacionamentoComFilme : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "FilmeCodigo",
                table: "Tbl_Atores",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateIndex(
                name: "IX_Tbl_Atores_FilmeCodigo",
                table: "Tbl_Atores",
                column: "FilmeCodigo");

            migrationBuilder.AddForeignKey(
                name: "FK_Tbl_Atores_Filmes_FilmeCodigo",
                table: "Tbl_Atores",
                column: "FilmeCodigo",
                principalTable: "Filmes",
                principalColumn: "Codigo",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Tbl_Atores_Filmes_FilmeCodigo",
                table: "Tbl_Atores");

            migrationBuilder.DropIndex(
                name: "IX_Tbl_Atores_FilmeCodigo",
                table: "Tbl_Atores");

            migrationBuilder.DropColumn(
                name: "FilmeCodigo",
                table: "Tbl_Atores");
        }
    }
}
