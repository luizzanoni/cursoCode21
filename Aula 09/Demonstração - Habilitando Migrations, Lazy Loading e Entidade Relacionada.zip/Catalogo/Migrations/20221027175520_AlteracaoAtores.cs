﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Catalogo.Migrations
{
    public partial class AlteracaoAtores : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropPrimaryKey(
                name: "PK_Atores",
                table: "Atores");

            migrationBuilder.RenameTable(
                name: "Atores",
                newName: "Tbl_Atores");

            migrationBuilder.AlterColumn<string>(
                name: "Nome",
                table: "Tbl_Atores",
                type: "varchar(50)",
                maxLength: 50,
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.AddPrimaryKey(
                name: "PK_Tbl_Atores",
                table: "Tbl_Atores",
                column: "Id");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropPrimaryKey(
                name: "PK_Tbl_Atores",
                table: "Tbl_Atores");

            migrationBuilder.RenameTable(
                name: "Tbl_Atores",
                newName: "Atores");

            migrationBuilder.AlterColumn<string>(
                name: "Nome",
                table: "Atores",
                type: "nvarchar(max)",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "varchar(50)",
                oldMaxLength: 50);

            migrationBuilder.AddPrimaryKey(
                name: "PK_Atores",
                table: "Atores",
                column: "Id");
        }
    }
}
