﻿using Catalogo.MeuNamespace;
using Catalogo.Models;
using Microsoft.EntityFrameworkCore;

namespace Catalogo.Data
{
    public class CatalogoContext : DbContext
    {
        public DbSet<Filme> Filmes { get; set; }
        public DbSet<Usuario> Usuarios { get; set; }
        public DbSet<Ator> Atores { get; set; }


        //"Data Source=(localdb)\MSSQLlocalDB;Integrated Security=True"

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {

            optionsBuilder.UseLazyLoadingProxies().UseSqlServer(@"Data Source=(localdb)\MSSqlLocalDB;Integrated Security=True;Initial Catalog=CatalogoFilmes");

            base.OnConfiguring(optionsBuilder);
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {


            modelBuilder.Entity<Ator>().Property(p => p.Nome)
                .HasMaxLength(50).IsRequired().HasColumnType("varchar");

            modelBuilder.Entity<Ator>().ToTable("Tbl_Atores");


            base.OnModelCreating(modelBuilder);
        }

    }
}
