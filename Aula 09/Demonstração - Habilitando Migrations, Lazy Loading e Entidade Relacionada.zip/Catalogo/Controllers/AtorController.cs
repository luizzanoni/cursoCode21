﻿using Catalogo.Data;
using Catalogo.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace Catalogo.Controllers
{
    public class AtorController : Controller
    {
        public CatalogoContext _context;
        public AtorController(CatalogoContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {

            return View(_context.Atores.ToList());
        }

        public IActionResult Cadastro()
        {


            ViewBag.Filmes = _context.Filmes.ToList().Select(f => new SelectListItem
            {
                Text = f.Titulo,
                Value = f.Codigo.ToString()
            });

            return View();

        }

        [HttpPost]
        public IActionResult Cadastro(Ator ator, int Filme)
        {

            ator.Filme = _context.Filmes.Find(Filme);

            _context.Atores.Add(ator);
            _context.SaveChanges();

            return RedirectToAction("Index");
        }

    }
}
