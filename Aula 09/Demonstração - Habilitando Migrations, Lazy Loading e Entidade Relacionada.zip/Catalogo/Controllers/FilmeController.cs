using Catalogo.Data;
using Catalogo.MeuNamespace;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Caching.Memory;
using System.Collections.Generic;

public class FilmeController : Controller
{

    public IMemoryCache _memCache;
    public CatalogoContext _context;

    public FilmeController(IMemoryCache memoryCache, CatalogoContext context)
    {
        _memCache = memoryCache;
        _context = context;
        _context.Database.EnsureCreated();
    }

    public IActionResult Index()
    {

        List<Filme> listaFilmes = _context.Filmes.OrderByDescending(f => f.Titulo).ToList();

        return View(listaFilmes);
    }

    public IActionResult Cadastro()
    {

        ViewBag.Categorias = GetCategorias();

        return View();
    }

    [HttpPost]
    public IActionResult Salvar(Filme filme)
    {

        if (ModelState.IsValid)
        {
            if (filme.Codigo == 0)
            {
                _context.Filmes.Add(filme);
                _context.SaveChanges();
            }
            else
            {
                Filme filmeDb = _context.Filmes.Find(filme.Codigo);
                filmeDb.Titulo = filme.Titulo;
                filmeDb.Lancamento = filme.Lancamento;
                filmeDb.Categoria = filme.Categoria;
                filmeDb.EmCartaz = filme.EmCartaz;

                _context.SaveChanges();

            }

            TempData["Mensagem"] = "Registro incluído com sucesso";

            return RedirectToAction("Index");
        }
        else
        {

            ViewBag.Mensagem = "Erro ao salvar um Filme, verifique os campos";
            return View("Cadastro");
        }

    }

    public IActionResult Editar(int Id)
    {
        ViewBag.Categorias = GetCategorias();

        Filme filme = _context.Filmes.Find(Id);

        return View("Cadastro", filme);

    }

    public IActionResult Excluir(int Id)
    {

        Filme filme = _context.Filmes.Find(Id);

        _context.Filmes.Remove(filme);

        _context.SaveChanges();

        TempData["Mensagem"] = "Registro excluído com sucesso";

        return RedirectToAction("Index");

    }

    public List<SelectListItem> GetCategorias()
    {

        List<SelectListItem> listaCategoria = new List<SelectListItem>{
            new SelectListItem {Text="Ação",Value="Ação"},
            new SelectListItem {Text="Terror",Value="Terror"},
            new SelectListItem {Text="Drama",Value="Drama"}
         };

        return listaCategoria;

    }

}