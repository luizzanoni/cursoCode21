﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Memory;
using SistemaAcademico.Models;

namespace SistemaAcademico.Controllers
{
    public class AlunoController : Controller
    {
        public IMemoryCache _memCache;

        public AlunoController(IMemoryCache memCache)
        {
            _memCache = memCache;
        }
        public IActionResult Index()
        {
            return View(GetAlunosCache());
        }

        [HttpGet]
        public IActionResult Cadastro()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Cadastro(Aluno aluno)
        {
            //Incluir no banco de dados
            ViewBag.MensagemSucesso = "Aluno incluído com sucesso";

            IList<Aluno> listaAlunos = GetAlunosCache();
            listaAlunos.Add(aluno);

            return View("Index", listaAlunos);
        }

        public IList<Aluno> GetAlunos()
        {
            List<Aluno> listaDeAlunos = new List<Aluno>();
            listaDeAlunos.Add(new Aluno { Nome = "Welington", Matricula = "001", Endereco = "Curitiba", Telefone = "99999999" });
            listaDeAlunos.Add(new Aluno { Nome = "Aluno 2", Matricula = "002", Endereco = "Curitiba", Telefone = "8888888" });
            listaDeAlunos.Add(new Aluno { Nome = "Aluno 3", Matricula = "003", Endereco = "Curitiba", Telefone = "8888888" });

            return listaDeAlunos;
        }

        public IList<Aluno> GetAlunosCache()
        {
            if (_memCache.Get("listaDeAlunos") == null)
            {
                List<Aluno> listaDeAlunos = new List<Aluno>();

                _memCache.Set("listaDeAlunos", listaDeAlunos, TimeSpan.FromHours(1));
            }

            return (IList<Aluno>)_memCache.Get("listaDeAlunos");
        }
    }
}
