﻿namespace Catalogo.Models
{
    public class Usuario
    {
        public int ID { get; set; }
        public string? Login { get; set; }

        public string? Senha { get; set; }
    }
}
