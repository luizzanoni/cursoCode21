using Catalogo.Data;
using Catalogo.MeuNamespace;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Caching.Memory;
using System.Collections.Generic;

public class FilmeController : Controller
{

    public IMemoryCache _memCache;
    public CatalogoContext _context;

    public FilmeController(IMemoryCache memoryCache, CatalogoContext context)
    {
        _memCache = memoryCache;
        _context = context;
        _context.Database.EnsureCreated();
    }

    public IActionResult Index()
    {

        List<Filme> listaFilmes = _context.Filmes.ToList();

        return View(listaFilmes);
    }

    public IActionResult Cadastro()
    {

        List<SelectListItem> listaCategoria = new List<SelectListItem>{
            new SelectListItem {Text="Ação",Value="Ação"},
            new SelectListItem {Text="Terror",Value="Terror"},
            new SelectListItem {Text="Drama",Value="Drama"}
         };

        ViewBag.Categorias = listaCategoria;

        return View();
    }

    [HttpPost]
    public IActionResult Salvar(Filme filme)
    {

        if (ModelState.IsValid)
        {


            List<Filme> listaFilmes = (List<Filme>)_memCache.Get("ListaFilmes");

            listaFilmes.Add(filme);

            return View("Index", listaFilmes);
        }
        else
        {

            ViewBag.Mensagem = "Erro ao salvar um Filme, verifique os campos";
            return View("Cadastro");
        }




    }

    public IActionResult Editar(int Id)
    {
        List<Filme> listaFilmes = (List<Filme>)_memCache.Get("ListaFilmes");

        Filme filme = listaFilmes.Find(f => f.Codigo == Id);

        return View("Cadastro", filme);

    }

}