﻿using System.ComponentModel.DataAnnotations.Schema;

namespace Catalogo.Models
{
    public class Usuario
    {

        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int ID { get; set; }
        public string? Login { get; set; }

        public string? Senha { get; set; }
    }
}
