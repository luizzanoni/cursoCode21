﻿namespace Catalogo.Models
{
    public class Usuario
    {
        public string? Login { get; set; }

        public string? Senha { get; set; }
    }
}
